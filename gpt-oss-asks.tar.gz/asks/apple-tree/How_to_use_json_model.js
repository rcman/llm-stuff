// How to use the Apple-tree.json model
//
// three.min.js (or the ES6 module version) must be loaded first

import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { ObjectLoader } from 'three/examples/jsm/loaders/ObjectLoader.js';

const scene   = new THREE.Scene();
const camera  = new THREE.PerspectiveCamera(45, innerWidth/innerHeight, 0.1, 100);
camera.position.set(5,4,6);
scene.add(camera);

const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(innerWidth, innerHeight);
document.body.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0,1,0);
controls.update();

scene.add(new THREE.AmbientLight(0xffffff, 0.6));
const sun = new THREE.DirectionalLight(0xffffff, 0.8);
sun.position.set(5,10,2);
scene.add(sun);

// ---------- Load the JSON ----------
const loader = new ObjectLoader();
loader.load('apple-tree.json', (tree) => {
  scene.add(tree);
  // optional: move a bit so you can see it clearly
  tree.position.set(-2,0,0);
});

// ---------- Render loop ----------
function animate() {
  requestAnimationFrame(animate);
  renderer.render(scene, camera);
}
animate();

