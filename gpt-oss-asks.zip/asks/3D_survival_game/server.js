// ---------------------------------------------------------------
//  server/server.js
//  Node.js + Express + Socket.IO
//  Persists player data in a tiny JSON file (lowdb)
// ---------------------------------------------------------------
const path = require('path');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { Low, JSONFile } = require('lowdb');

// ---------- Express ----------
const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Serve static client files
app.use(express.static(path.join(__dirname, '..', 'public')));

// ---------- LowDB (tiny JSON DB) ----------
const dbFile = path.join(__dirname, 'db', 'players.json');
const adapter = new JSONFile(dbFile);
const db = new Low(adapter);
await db.read();
db.data ??= { players: {} };
await db.write();

// ---------- Helper: Save a player ----------
async function savePlayer(id, data) {
  db.data.players[id] = data;
  await db.write();
}

// ---------- Socket.IO ----------
io.on('connection', async (socket) => {
  console.log(`⚡ New client: ${socket.id}`);

  // ---- Load / create player data ----
  let player = db.data.players[socket.id];
  if (!player) {
    // New player – give starter inventory
    player = {
      id: socket.id,
      name: `Player_${socket.id.slice(0, 4)}`,
      position: { x: 0, y: 2, z: 0 },
      rotation: { y: 0 },
      inventory: {
        quick: [],      // 8 slots
        bag: []         // unlimited for prototype
      },
      health: 100,
      // ... any other persistent fields
    };
    await savePlayer(socket.id, player);
  }

  // ---- Send current world snapshot to the newcomer ----
  socket.emit('init', {
    self: player,
    others: Object.values(db.data.players).filter(p => p.id !== socket.id)
  });

  // ---- Broadcast this player to everyone else ----
  socket.broadcast.emit('playerJoined', player);

  // ---- Handle movement / rotation updates from client ----
  socket.on('updateSelf', async (data) => {
    // data: { position:{x,y,z}, rotation:{y} }
    const p = db.data.players[socket.id];
    if (!p) return;
    p.position = data.position;
    p.rotation = data.rotation;
    await savePlayer(socket.id, p);
    // broadcast to others (but not back to sender)
    socket.broadcast.emit('updateOther', { id: socket.id, ...data });
  });

  // ---- Handle inventory changes (crafting, looting, etc.) ----
  socket.on('inventoryUpdate', async (inv) => {
    const p = db.data.players[socket.id];
    if (!p) return;
    p.inventory = inv;
    await savePlayer(socket.id, p);
    // you could also broadcast changes if you want others to see e.g. a placed chest
  });

  // ---- Handle disconnect ----
  socket.on('disconnect', async () => {
    console.log(`❌ Client left: ${socket.id}`);
    // keep player data for later login, or delete if you prefer:
    // delete db.data.players[socket.id];
    // await db.write();
    socket.broadcast.emit('playerLeft', socket.id);
  });
});

// ---------- Start ----------
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`🚀 Server listening on http://localhost:${PORT}`));

