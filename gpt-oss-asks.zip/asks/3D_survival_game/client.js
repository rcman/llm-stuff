/* --------------------------------------------------------------
   client.js
   Core Three.js scene, third‑person controller, networking,
   resource gathering & simple UI placeholders.
   -------------------------------------------------------------- */

const socket = io();                     // <-- connect to server

// ---------- Global vars ----------
let scene, camera, renderer, controls;
let player = null;                      // our own player object
let otherPlayers = {};                  // map: socketId → THREE.Group
let world = {};                         // keep references to trees, rocks, etc.
let clock = new THREE.Clock();

// ---------- Init Three.js ----------
initThree();
initWorld();
animate();

// ---------- Socket.IO Handlers ----------
socket.on('init', (data) => {
  console.log('⚙️ init', data);
  player = createPlayerMesh(data.self);
  scene.add(player.group);
  // other players already in world
  data.others.forEach(p => addOtherPlayer(p));
});

socket.on('playerJoined', (data) => addOtherPlayer(data));
socket.on('updateOther', (data) => updateOtherPlayer(data));
socket.on('playerLeft', (id) => removeOtherPlayer(id));

// ----------------------------------------------------------------
// 1️⃣  THREE.JS SETUP
// ----------------------------------------------------------------
function initThree() {
  const canvas = document.getElementById('glcanvas');

  renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(window.devicePixelRatio);
  renderer.setClearColor(0x87ceeb); // sky blue

  scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x87ceeb, 0.0015); // light fog

  // Camera – third‑person view
  camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 5000);
  camera.position.set(0, 5, -12);
  camera.lookAt(0, 0, 0);

  // Simple orbit controls for debugging (lock pointer for real game)
  controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.target.set(0, 2, 0);
}

// ----------------------------------------------------------------
// 2️⃣  WORLD GENERATION (static for prototype)
// ----------------------------------------------------------------
function initWorld() {
  // Ground plane with a simple height map (you could use a perlin generator)
  const size = 1000;
  const segments = 256;

  const geometry = new THREE.PlaneGeometry(size, size, segments, segments);
  geometry.rotateX(-Math.PI / 2);

  // Random hills (very basic)
  for (let i = 0; i < geometry.attributes.position.count; i++) {
    const vertex = new THREE.Vector3();
    vertex.fromBufferAttribute(geometry.attributes.position, i);
    const distance = Math.hypot(vertex.x, vertex.z);
    const height = Math.max(0, 30 - distance * 0.03) + Math.random() * 2;
    vertex.y = height;
    geometry.attributes.position.setXYZ(i, vertex.x, vertex.y, vertex.z);
  }
  geometry.computeVertexNormals();

  const groundMat = new THREE.MeshStandardMaterial({ color: 0x556b2f });
  const ground = new THREE.Mesh(geometry, groundMat);
  scene.add(ground);

  // Lights
  const hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 0.9);
  hemi.position.set(0, 200, 0);
  scene.add(hemi);
  const dirLight = new THREE.DirectionalLight(0xffffff, 0.6);
  dirLight.position.set(-300, 400, -300);
  scene.add(dirLight);

  // Water (low‑poly plane with Water2 shader)
  const waterGeometry = new THREE.PlaneGeometry(size, size);
  const water = new THREE.Water(waterGeometry, {
    color: 0x001e0f,
    scale: 1,
    flowDirection: new THREE.Vector2(1, 1),
    textureWidth: 512,
    textureHeight: 512
  });
  water.rotation.x = -Math.PI / 2;
  water.position.y = 2; // water level
  scene.add(water);
  world.water = water;

  // ------------------------------------------------------------
  //  Populate trees, rocks, barrels, buildings, etc.
  // ------------------------------------------------------------
  const loader = new THREE.ObjectLoader(); // works with .json models

  // Helper to place many copies of a model
  function scatterModel(url, count, radius, yOffset = 0, onLoad) {
    loader.load(url, (model) => {
      for (let i = 0; i < count; i++) {
        const clone = model.clone();
        const angle = Math.random() * Math.PI * 2;
        const dist = Math.random() * radius;
        const x = Math.cos(angle) * dist;
        const z = Math.sin(angle) * dist;
        const y = getHeightAt(x, z) + yOffset;
        clone.position.set(x, y, z);
        clone.traverse(o => { if (o.isMesh) o.castShadow = true; });
        scene.add(clone);
        // store for simple ray‑cast collision later
        world[`obj_${url}_${i}`] = clone;
      }
      if (onLoad) onLoad();
    });
  }

  // Simple height‑lookup (uses ground geometry)
  function getHeightAt(x, z) {
    // brute‑force: nearest vertex (good enough for prototype)
    const pos = new THREE.Vector3(x, 0, z);
    const ray = new THREE.Raycaster(new THREE.Vector3(x, 500, z), new THREE.Vector3(0, -1, 0));
    const intersect = ray.intersectObject(ground)[0];
    return intersect ? intersect.point.y : 0;
  }

  // 1k trees
  scatterModel('assets/models/appletree.json', 1000, 500, 0);
  // 1k rocks
  scatterModel('assets/models/storagebox.json', 1000, 500, 0);
  // Barrels (searchable loot)
  scatterModel('assets/models/barrel.json', 150, 500, 0);
  // Empty buildings (crates inside)
  scatterModel('assets/models/building1.json', 50, 400, 0);
  // ... add more as you like
}

// ----------------------------------------------------------------
// 3️⃣  PLAYER CREATION
// ----------------------------------------------------------------
function createPlayerMesh(data) {
  const group = new THREE.Group();

  // Load the human model – you can replace with a simple capsule for testing
  const loader = new THREE.ObjectLoader();
  loader.load('assets/models/human.json', (model) => {
    model.scale.set(0.5, 0.5, 0.5);
    group.add(model);
  });

  // Position from server
  group.position.set(data.position.x, data.position.y, data.position.z);
  group.rotation.y = data.rotation.y;

  // Attach a simple invisible "hitbox" for ray‑casting
  const hitbox = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.5, 1.0, 4, 8),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  group.add(hitbox);
  group.userData = { id: data.id, hitbox };

  return { id: data.id, group };
}

// ----------------------------------------------------------------
// 4️⃣  OTHER PLAYERS (ghosts)
// ----------------------------------------------------------------
function addOtherPlayer(p) {
  const other = createPlayerMesh(p);
  scene.add(other.group);
  otherPlayers[p.id] = other;
}
function updateOtherPlayer({ id, position, rotation }) {
  const other = otherPlayers[id];
  if (!other) return;
  other.group.position.set(position.x, position.y, position.z);
  other.group.rotation.y = rotation.y;
}
function removeOtherPlayer(id) {
  const other = otherPlayers[id];
  if (other) {
    scene.remove(other.group);
    delete otherPlayers[id];
  }
}

// ----------------------------------------------------------------
// 5️⃣  INPUT & CONTROLS (WASD + mouse look)
// ----------------------------------------------------------------
const keys = { w: false, a: false, s: false, d: false };
window.addEventListener('keydown', (e) => { keys[e.key.toLowerCase()] = true; });
window.addEventListener('keyup',   (e) => { keys[e.key.toLowerCase()] = false; });

let pointerLocked = false;
document.body.addEventListener('click', () => {
  if (!pointerLocked) {
    renderer.domElement.requestPointerLock();
  }
});
document.addEventListener('pointerlockchange', () => {
  pointerLocked = document.pointerLockElement === renderer.domElement;
});

let yaw = 0, pitch = 0;
document.addEventListener('mousemove', (e) => {
  if (!pointerLocked) return;
  const sensitivity = 0.002;
  yaw   -= e.movementX * sensitivity;
  pitch -= e.movementY * sensitivity;
  pitch = Math.max(-Math.PI/2, Math.min(Math.PI/2, pitch));
});

// ----------------------------------------------------------------
// 6️⃣  GAME LOOP
// ----------------------------------------------------------------
function animate() {
  requestAnimationFrame(animate);
  const delta = clock.getDelta();

  // ---- Player movement ----
  if (player) {
    const speed = 6; // m/s
    const move = new THREE.Vector3();

    if (keys.w) move.z -= 1;
    if (keys.s) move.z += 1;
    if (keys.a) move.x -= 1;
    if (keys.d) move.x += 1;
    move.normalize().multiplyScalar(speed * delta);

    // rotate movement direction by camera yaw
    const rot = new THREE.Euler(0, yaw, 0);
    move.applyEuler(rot);

    // simple gravity & ground clamp
    player.group.position.add(move);
    const groundY = getGroundHeight(player.group.position.x, player.group.position.z) + 1.6;
    player.group.position.y = groundY;

    // apply rotation (look direction)
    player.group.rotation.y = yaw;

    // send compact update to server (30 Hz)
    if (socket.connected) {
      socket.emit('updateSelf', {
        position: player.group.position,
        rotation: { y: player.group.rotation.y }
      });
    }
  }

  // ---- Camera follows player ----
  if (player) {
    const camOffset = new THREE.Vector3(0, 4, -10).applyEuler(new THREE.Euler(pitch, yaw, 0));
    camera.position.copy(player.group.position).add(camOffset);
    camera.lookAt(player.group.position);
  }

  // ---- Update water (simple wave) ----
  if (world.water) world.water.material.uniforms['time'].value += delta;

  controls.update(); // optional orbit‑controls damping

  renderer.render(scene, camera);
}

// ----------------------------------------------------------------
// 7️⃣  GROUND HEIGHT LOOKUP (used by player & objects)
// ----------------------------------------------------------------
function getGroundHeight(x, z) {
  const ray = new THREE.Raycaster(new THREE.Vector3(x, 500, z), new THREE.Vector3(0, -1, 0));
  const intersect = ray.intersectObject(scene.getObjectByName('ground') || scene.children[0])[0];
  return intersect ? intersect.point.y : 0;
}

// ----------------------------------------------------------------
// 8️⃣  SIMPLE UI (inventory / crafting / building)
// ----------------------------------------------------------------
function toggleUI(id) {
  const el = document.getElementById(id);
  el.style.display = (el.style.display === 'none' || el.style.display === '') ? 'block' : 'none';
}
window.addEventListener('keydown', (e) => {
  if (e.key === 'i' || e.key === 'I') toggleUI('inventory');
  if (e.key === 'c' || e.key === 'C') toggleUI('crafting');
  if (e.key === 'b' || e.key === 'B') toggleUI('building');
});

/* --------------------------------------------------------------
   Resource gathering, crafting, building, and AI
   ----------------------------------------------------------------
   The prototype above already gives you:

   • A 3‑D world with trees, rocks, water, fog.
   • Multiplayer sync (players see each other).
   • Persistent player position / inventory (saved on the server).

   From here you can plug in the remaining systems:

   1️⃣  **Ray‑cast interaction** – on mouse‑click cast a ray from the
       camera to see if you hit a tree, rock, barrel, animal, etc.
       When you hit a tree and hold the axe key, send a
       `gather` message to the server.  The server validates the
       tool, deducts durability, adds `wood` to the player's inventory,
       and broadcasts a small “chop” animation.

   2️⃣  **Crafting UI** – read `player.inventory` (kept locally, kept
       in sync with the server via `inventoryUpdate`).  When the
       player presses a craft button, check recipes (hard‑coded or
       JSON) and, if the resources exist, remove them and add the
       crafted item to the quick‑slot array.  Send the updated inventory
       to the server.

   3️⃣  **Building System** – when the player presses **B**, show a
       “ghost” preview of the selected blueprint (foundation, wall,
       door …).  Snap it to the world grid (e.g. 1 m cells) and, on
       confirm, deduct the required resources and instantiate the
       object both locally *and* broadcast a `placeObject` packet so
       every client adds the same mesh.

   4️⃣  **Animals (AI)** – create a tiny finite‑state‑machine for each
       animal type (rabbit, chicken, wolf, bear).  Use simple
       steering behaviours (wander, flee, chase).  When an animal
       collides with water, destroy it and optionally spawn “bones”
       loot.

   5️⃣  **Inventory System** – the HTML placeholders in the UI can be
       turned into a grid of `<div class="slot">` elements.  Drag‑&‑drop
       events move items between the bag and the quick‑bar.

   6️⃣  **Persisting Everything** – you already have a JSON file per
       player.  You can also store world‑placed objects in a separate
       `world.json` file (or a DB table) and load them on server start.
       When a client disconnects, the server keeps its data so the
       player can come back later.

   7️⃣  **Performance** – for 1000+ trees/rocks you will want
       **InstancedMesh** instead of individual meshes.  The scatter
       function above can be swapped with an Instanced version once
       you’re happy with the gameplay.

   -------------------------------------------------------------- */
